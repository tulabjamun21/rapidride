package com.rapidride.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10233F)
private val Blue = Color(0xFF246BFD)
private val Pale = Color(0xFFF3F6FB)
private val Ink = Color(0xFF1C2636)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RapidRideApp() }
    }
}

@Composable
fun RapidRideApp() {
    var screen by remember { mutableStateOf("home") }
    var pickup by remember { mutableStateOf("Current location") }
    var destination by remember { mutableStateOf("") }
    var rideType by remember { mutableStateOf("Rapid Go") }
    var booked by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Pale, surface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Pale) {
            when (screen) {
                "home" -> HomeScreen(pickup, { pickup = it }, destination, { destination = it }, { screen = "booking" })
                "booking" -> BookingScreen(pickup, destination, rideType, { rideType = it }, { screen = "home" }, {
                    booked = true
                    screen = "tracking"
                })
                else -> TrackingScreen(pickup, destination, rideType, booked, { screen = "home" })
            }
        }
    }
}

@Composable
private fun HomeScreen(pickup: String, onPickup: (String) -> Unit, destination: String, onDestination: (String) -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 24.dp, vertical = 26.dp)) {
            Column {
                Text("RapidRide", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text("Your ride. Your way.", color = Color(0xFFCFD9E8), fontSize = 14.sp)
                Spacer(Modifier.height(22.dp))
                Text("Where are you going?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    LabeledField("PICKUP LOCATION", pickup, onPickup, "Enter pickup location")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(Blue, CircleShape))
                        Spacer(Modifier.width(10.dp))
                        HorizontalDivider(Modifier.weight(1f), color = Color(0xFFDCE3ED))
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.size(10.dp).background(Color(0xFF18A878), CircleShape))
                    }
                    LabeledField("DROP LOCATION", destination, onDestination, "Where to?")
                }
            }
            Text("QUICK & COMFORTABLE", color = Color(0xFF68758A), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickTile("🚗", "Car", "Everyday rides", Modifier.weight(1f))
                QuickTile("🏍️", "Bike", "Beat the traffic", Modifier.weight(1f))
            }
            Button(onClick = onContinue, enabled = destination.isNotBlank(), modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Find a ride  →", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text("Demo version · bookings are stored on this screen only", color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun LabeledField(label: String, value: String, onValue: (String) -> Unit, placeholder: String) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(label, color = Color(0xFF69778D), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        OutlinedTextField(value = value, onValueChange = onValue, placeholder = { Text(placeholder) }, singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences), modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFFDCE3ED)))
    }
}

@Composable
private fun QuickTile(emoji: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(emoji, fontSize = 27.sp)
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BookingScreen(pickup: String, destination: String, rideType: String, onRideType: (String) -> Unit, onBack: () -> Unit, onBook: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Choose your ride", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text("Select an option for your trip", color = Color.Gray)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("📍  $pickup", color = Ink)
                HorizontalDivider(color = Color(0xFFE4E9F0))
                Text("🏁  $destination", color = Ink)
            }
        }
        listOf(Triple("Rapid Go", "🚗", "₹99 approx."), Triple("Rapid Bike", "🏍️", "₹39 approx."), Triple("Rapid XL", "🚙", "₹169 approx.")).forEach { option ->
            val selected = rideType == option.first
            Card(onClick = { onRideType(option.first) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFEAF0FF) else Color.White), border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, Blue) else null) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(option.second, fontSize = 28.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) { Text(option.first, fontWeight = FontWeight.Bold, color = Ink); Text("Estimated fare", color = Color.Gray, fontSize = 12.sp) }
                    Text(option.third, color = Navy, fontWeight = FontWeight.Bold)
                }
            }
        }
        Button(onClick = onBook, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) { Text("Confirm booking", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        Text("Fares are sample estimates for this prototype.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun TrackingScreen(pickup: String, destination: String, rideType: String, booked: Boolean, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("RapidRide", color = Blue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text("You're all set!", color = Navy, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✓", fontSize = 44.sp, color = Color.White)
                Text("Booking request created", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Demo booking · no driver dispatched", color = Color(0xFFCFD9E8), textAlign = TextAlign.Center)
            }
        }
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("TRIP DETAILS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("🚘  $rideType", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Pickup: $pickup", color = Ink)
                Text("Drop: $destination", color = Ink)
                Text("Status: Demo only", color = Blue, fontWeight = FontWeight.Bold)
            }
        }
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text("Back to home") }
    }
}

# RapidRide Android app — starter prototype

A Kotlin + Jetpack Compose Android Studio project created from scratch.

## Current features
- Home screen with pickup and destination fields
- Ride selection (Rapid Go, Rapid Bike, Rapid XL)
- Sample fare estimates
- Booking confirmation / demo tracking screen
- Local in-memory navigation and state

## Important limitations
This is a **UI prototype**, not a live ride-hailing service. It does not yet include a real map, GPS, user authentication, Firebase storage, driver dispatch, payment processing, or live tracking. Sample fares are illustrative only.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Extract this folder and choose **Open** in Android Studio.
3. Let Gradle sync and install the required Android SDK platform (API 35) if prompted.
4. For a test APK, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio normally writes it to `app/build/outputs/apk/debug/app-debug.apk`.

Command line alternative from this folder, on a machine with Android SDK and Gradle available:
`gradle assembleDebug`

Package: `com.rapidride.app`  
Minimum Android: 7.0 (API 24)  
Version: 1.0

## Build APK using only an Android phone (GitHub Actions)
1. Create a GitHub repository and upload the contents of this `RapidRide` folder (not the outer ZIP folder).
2. Make sure `.github/workflows/android.yml` is included. On GitHub, open **Actions** and enable workflows if prompted.
3. Push/commit the files to the `main` branch, or open Actions → **Build RapidRide APK** → **Run workflow**.
4. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `RapidRide-debug-apk`.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Allow installation from that browser/files app if Android asks.

This creates a debug APK for testing. Maps/Firebase credentials and real ride services are not configured in this starter project.
